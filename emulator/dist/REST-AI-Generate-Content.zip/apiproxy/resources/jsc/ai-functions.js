if (!String.prototype.startsWith) {
  String.prototype.startsWith = function(search, pos) {
    return this.substr(!pos || pos < 0 ? 0 : +pos, search.length) === search;
  };
}
if (!String.prototype.endsWith) {
  String.prototype.endsWith = function(search, this_len) {
    if (this_len === undefined || this_len > this.length) {
      this_len = this.length;
    }
    return this.substring(this_len - search.length, this_len) === search;
  };
}
if (!String.prototype.includes) {
  String.prototype.includes = function(search, start) {
    if (typeof start !== 'number') {
      start = 0;
    }
    if (start + search.length > this.length) {
      return false;
    } else {
      return this.indexOf(search, start) !== -1;
    }
  };
}

function safeJsonParse(str) {
  if (!str) return null;
  if (typeof str === "object") return str;
  if (typeof str !== "string") return null;
  var cleaned = str.trim();
  if (cleaned.indexOf("{") !== 0 && cleaned.indexOf("[") !== 0) return null;
  try {
    return JSON.parse(cleaned);
  } catch (e1) {
    try {
      var sanitized = cleaned.replace(/\r?\n/g, "\\n");
      return JSON.parse(sanitized);
    } catch (e2) {
      return null;
    }
  }
}

function extractGoogleInput(contents) {
  if (!contents || !Array.isArray(contents)) return "";
  for (var i = contents.length - 1; i >= 0; i--) {
    var item = contents[i];
    if (item && item.role && item.role.toLowerCase() === "user" && item.parts && Array.isArray(item.parts)) {
      for (var p = item.parts.length - 1; p >= 0; p--) {
        if (item.parts[p] && item.parts[p].text) {
          return item.parts[p].text;
        }
      }
    }
  }
  return "";
}

function extractMessagesInput(messages) {
  if (!messages || !Array.isArray(messages)) return "";
  for (var i = messages.length - 1; i >= 0; i--) {
    var msg = messages[i];
    if (msg && msg.role && msg.role.toLowerCase() === "user") {
      if (typeof msg.content === "string") {
        return msg.content;
      }
      if (Array.isArray(msg.content)) {
        var parts = [];
        for (var c = 0; c < msg.content.length; c++) {
          var part = msg.content[c];
          if (part && part.type === "text" && part.text) {
            parts.push(part.text);
          } else if (typeof part === "string") {
            parts.push(part);
          }
        }
        if (parts.length > 0) {
          return parts.join(" ");
        }
      }
    }
  }
  return "";
}

function safeStringify(val) {
  if (val === null || val === undefined) return "";
  if (typeof val === "string") return val;
  try {
    if (typeof java !== "undefined" && java.lang && java.lang.String) {
      return String(java.lang.String.valueOf(val));
    }
  } catch (e) {}
  try {
    return "" + val;
  } catch (e) {}
  try {
    return String(val);
  } catch (e) {}
  return "";
}

function getBodyString(content) {
  if (content === null || content === undefined) return "";
  if (typeof content === "string") return content;
  return safeStringify(content);
}

function getRequestInfo(urlString, content, contentType) {
  var info = {
    input: "",
    rawModelName: "",
    modelName: "unknown",
    protocol: "unknown",
    requestType: "text"
  };

  var url = urlString || "";
  var lowerUrl = url.toLowerCase();

  // 1. Detect requestType from URL
  if (lowerUrl.includes("/audio/speech") || lowerUrl.includes("/speech/audio")) {
    info.requestType = "audio-text";
  } else if (lowerUrl.includes("/audio/transcription") || lowerUrl.includes("/audio/translation")) {
    info.requestType = "audio-data";
  } else if (lowerUrl.includes("/images/generations") || lowerUrl.includes("/images/edits") || lowerUrl.includes("/images/variations")) {
    info.requestType = "image-generation";
  } else if (lowerUrl.includes("/embeddings")) {
    info.requestType = "embeddings";
  }

  // Parse content JSON or multipart data
  var contentData = null;
  if (typeof content === "object" && content !== null && !content.asJSON && !content.asString) {
    if (content.model !== undefined || content.contents !== undefined || content.messages !== undefined) {
      contentData = content;
    }
  }

  if (!contentData) {
    var bodyStr = getBodyString(content);
    var isMultipart = (info.requestType === "audio-data") ||
                      (contentType && contentType.toLowerCase().indexOf("multipart") !== -1) ||
                      (bodyStr && bodyStr.indexOf("--") === 0);

    if (bodyStr && isMultipart) {
      contentData = parseMultipartFormData(bodyStr, contentType);
    } else if (content) {
      if (typeof content === "object" && content.asJSON) {
        contentData = content.asJSON;
      } else if (typeof content === "string") {
        try {
          contentData = JSON.parse(content);
        } catch (e) {}
      } else if (bodyStr && bodyStr !== "[object Object]") {
        try {
          contentData = JSON.parse(bodyStr);
        } catch (e) {}
      } else if (typeof content === "object") {
        contentData = content;
      }
    }
  }

  if (contentData && typeof contentData === "object") {
    // Fallback requestType check from payload if URL didn't specify
    if (info.requestType === "text") {
      if (contentData["voice"] !== undefined && contentData["input"] !== undefined) {
        info.requestType = "audio-text";
      }
    }

    // 2. Extract modelName and rawModelName from payload
    if (contentData["model"] && typeof contentData["model"] === "string") {
      info.rawModelName = contentData["model"];
      var modelParts = info.rawModelName.split("/");
      info.modelName = modelParts[modelParts.length - 1];
    } else if (contentData["modelVersion"] && typeof contentData["modelVersion"] === "string") {
      info.rawModelName = contentData["modelVersion"];
      info.modelName = contentData["modelVersion"];
    }
  }

  if (info.requestType === "audio-data" && info.protocol === "unknown") {
    info.protocol = "openai";
  }

  // If modelName still unknown, extract from GCP publisher URL format
  if (info.modelName === "unknown" && url) {
    if (url.includes("/publishers/anthropic/models/")) {
      var aParts = url.split("/publishers/anthropic/models/");
      if (aParts.length > 1) {
        info.modelName = aParts[1].split(":")[0];
      }
    } else if (url.includes("/publishers/google/models/")) {
      var gParts = url.split("/publishers/google/models/");
      if (gParts.length > 1) {
        info.modelName = gParts[1].split(":")[0];
      }
    }
  }

  // 3. Detect protocol and extract main input prompt/text
  if (contentData && typeof contentData === "object") {
    if (contentData["contents"] && Array.isArray(contentData["contents"])) {
      info.protocol = "google";
      info.input = extractGoogleInput(contentData["contents"]);
    } else if (contentData["messages"] && Array.isArray(contentData["messages"])) {
      if (
        contentData["system"] !== undefined ||
        contentData["anthropic_version"] !== undefined ||
        contentData["top_k"] !== undefined
      ) {
        info.protocol = "anthropic";
      } else {
        info.protocol = "openai";
      }
      info.input = extractMessagesInput(contentData["messages"]);
    } else if (contentData["prompt"] !== undefined) {
      info.protocol = "openai";
      if (typeof contentData["prompt"] === "string") {
        info.input = contentData["prompt"];
      } else if (Array.isArray(contentData["prompt"])) {
        info.input = contentData["prompt"].join(" ");
      }
    } else if (contentData["input"] !== undefined) {
      info.protocol = "openai";
      if (typeof contentData["input"] === "string") {
        info.input = contentData["input"];
      } else if (Array.isArray(contentData["input"])) {
        info.input = contentData["input"].join(" ");
      }
    }
  }

  if (info.protocol === "unknown" && url) {
    if (url.includes("/publishers/google/")) {
      info.protocol = "google";
    } else if (url.includes("/publishers/anthropic/")) {
      info.protocol = "anthropic";
    }
  }

  return info;
}

function getModelName(urlString, contentString) {
  var info = getRequestInfo(urlString, contentString);
  return info.modelName;
}

function getPrompts(contentData) {
  var info = getRequestInfo("", contentData);
  return {
    userPrompt: info.input,
    allUserPrompts: info.input,
    protocol: info.protocol
  };
}

function getTargetRoute(modelName, config) {
  var result = {
    provider: "unknown",
    region: "global",
    cleanModelName: modelName || "",
    targetRoute: ""
  };

  if (!modelName || modelName === "unknown") {
    return result;
  }

  var parsedConfig = null;
  if (config) {
    if (typeof config === "string") {
      try {
        parsedConfig = JSON.parse(config);
      } catch (e) {}
    } else if (typeof config === "object") {
      parsedConfig = config;
    }
  }

  var currentModel = modelName;

  // 1. Check mappings in config
  if (parsedConfig && parsedConfig.mappings) {
    if (parsedConfig.mappings[currentModel]) {
      currentModel = parsedConfig.mappings[currentModel];
      result.mappedModelName = currentModel;
    } else {
      var rawProv = "";
      var clean = currentModel;
      if (currentModel.indexOf("/") !== -1) {
        var p = currentModel.split("/");
        rawProv = p[0];
        clean = p.slice(1).join("/");
      }
      var provModelKey = rawProv ? (rawProv + "/" + clean) : clean;
      if (parsedConfig.mappings[provModelKey]) {
        currentModel = parsedConfig.mappings[provModelKey];
        result.mappedModelName = currentModel;
      } else if (parsedConfig.mappings[clean]) {
        currentModel = parsedConfig.mappings[clean];
        result.mappedModelName = currentModel;
      }
    }
  }

  var rawProvider = "";
  var cleanModel = currentModel;

  if (currentModel.indexOf("/") !== -1) {
    var parts = currentModel.split("/");
    rawProvider = parts[0];
    cleanModel = parts.slice(1).join("/");
  }

  if (rawProvider) {
    result.provider = rawProvider;
  } else {
    var lower = currentModel.toLowerCase();
    if (lower.indexOf("gemini") !== -1 || lower.indexOf("embedding") !== -1) {
      result.provider = "google";
      result.targetRoute = "googlecloud";
    } else if (lower.indexOf("claude") !== -1) {
      result.provider = "anthropic";
      result.targetRoute = "anthropic";
    } else if (lower.indexOf("gpt") !== -1) {
      result.provider = "openai";
      result.targetRoute = "openai";
    } else {
      result.provider = "unknown";
    }
  }

  result.cleanModelName = cleanModel;

  // 2. Straight model string mapping to target in models
  if (parsedConfig && parsedConfig.models) {
    if (parsedConfig.models[currentModel]) {
      result.targetRoute = parsedConfig.models[currentModel];
    } else if (parsedConfig.models[modelName]) {
      result.targetRoute = parsedConfig.models[modelName];
    } else if (parsedConfig.models[cleanModel]) {
      result.targetRoute = parsedConfig.models[cleanModel];
    }

    if (!result.targetRoute) {
      for (var modelKey in parsedConfig.models) {
        if (currentModel.includes(modelKey) || modelKey.includes(currentModel)) {
          result.targetRoute = parsedConfig.models[modelKey];
          break;
        }
      }
    }
  }

  return result;
}

function setPrompt(contentData, userPrompt) {
  if (contentData && contentData["contents"]) {
    // gemini format
    for (var i = contentData["contents"].length - 1; i >= 0; i--) {
      var content = contentData["contents"][i];
      if (
        content &&
        content["role"] &&
        content["role"].toLowerCase() == "user" &&
        content["parts"]
      ) {
        for (var p = content["parts"].length - 1; p >= 0; p--) {
          var part = content["parts"][p];
          if (content["parts"][p]["text"]) {
            content["parts"][p]["text"] = userPrompt;
            break;
          }
        }
      }
    }
  } else if (contentData && contentData["messages"]) {
    // oapi format
    for (var i = contentData["messages"].length - 1; i >= 0; i--) {
      var message = contentData["messages"][i];
      if (message && message["role"] && message["role"].toLowerCase() == "user") {
        if (message["content"]) {
          message["content"] = userPrompt;
          break;
        }
      }
    }
  }

  return contentData;
}

function getResponse(contentData) {
  var responseText = "";

  if (contentData && contentData["candidates"] && contentData["candidates"].length > 0) {
    // gemini format
    for (var i = contentData["candidates"].length - 1; i >= 0; i--) {
      var candidate = contentData["candidates"][i];
      if (
        candidate &&
        candidate["content"] &&
        candidate["content"]["parts"] &&
        candidate["content"]["parts"].length > 0
      ) {
        for (var p = candidate["content"]["parts"].length - 1; p >= 0; p--) {
          var part = candidate["content"]["parts"][p];
          if (part && part["text"]) {
            responseText = part["text"];
            break;
          }
        }
      }
    }
  } else if (contentData && contentData["choices"] && contentData["choices"].length > 0) {
    // openmodel format
    for (var i = contentData["choices"].length - 1; i >= 0; i--) {
      var choice = contentData["choices"][i];
      if (choice && choice["message"] && choice["message"]["content"]) {
        responseText = choice["message"]["content"];
        break;
      }
    }
  } else if (contentData && contentData["content"] && contentData["content"].length > 0) {
    // claude format
    for (var i = contentData["content"].length - 1; i >= 0; i--) {
      var content = contentData["content"][i];
      if (content && content["type"] == "text") {
        responseText = content["text"];
        break;
      }
    }
  }

  return responseText;
}

function setResponse(contentData, content) {
  if (contentData && contentData["candidates"] && contentData["candidates"].length > 0) {
    // gemini format
    for (var i = contentData["candidates"].length - 1; i >= 0; i--) {
      var candidate = contentData["candidates"][i];
      if (
        candidate &&
        candidate["content"] &&
        candidate["content"]["parts"] &&
        candidate["content"]["parts"].length > 0
      ) {
        for (var p = candidate["content"]["parts"].length - 1; p >= 0; p--) {
          var part = candidate["content"]["parts"][p];
          if (part && part["text"]) {
            part["text"] = content;
            break;
          }
        }
      }
    }
  } else if (contentData && contentData["choices"] && contentData["choices"].length > 0) {
    // openmodel format
    for (var i = contentData["choices"].length - 1; i >= 0; i--) {
      var choice = contentData["choices"][i];
      if (choice && choice["message"] && choice["message"]["content"]) {
        choice["message"]["content"] = content;
        break;
      }
    }
  } else if (contentData && contentData["content"] && contentData["content"].length > 0) {
    // claude format
    for (var i = contentData["content"].length - 1; i >= 0; i--) {
      var claudeContent = contentData["content"][i];
      if (claudeContent && claudeContent["type"] == "text") {
        claudeContent["text"] = content;
        break;
      }
    }
  }

  return contentData;
}

function getUsageData(contentString) {
  var usageData = {
    model: "",
    requestTokenCount: 0,
    responseTokenCount: 0,
    totalTokenCount: 0,
    usageFound: false
  };

  if (!contentString) {
    return usageData;
  }

  var cleaned = contentString.trim();

  // Return early for stream markers, ping events, or non-data frames to avoid JSON parse errors
  if (
    cleaned.indexOf("[DONE]") !== -1 ||
    cleaned.indexOf("message_stop") !== -1 ||
    cleaned.indexOf("content_block") !== -1 ||
    cleaned.indexOf("event: ping") !== -1
  ) {
    return usageData;
  }

  // Extract last JSON object from data: lines if present
  if (cleaned.indexOf("data:") !== -1) {
    var lines = cleaned.split(/\r?\n/);
    for (var i = lines.length - 1; i >= 0; i--) {
      var l = lines[i].trim();
      if (l.indexOf("data:") === 0) {
        var candidate = l.substring(5).trim();
        if (candidate.indexOf("{") === 0) {
          cleaned = candidate;
          break;
        }
      }
    }
  } else if (cleaned.indexOf("event: ") === 0) {
    var firstBrace = cleaned.indexOf("{");
    if (firstBrace !== -1) {
      cleaned = cleaned.substring(firstBrace).trim();
    }
  }

  if (!cleaned || cleaned.indexOf("{") !== 0) {
    return usageData;
  }

  try {
    var contentData = JSON.parse(cleaned);

    // model
    if (contentData["model"]) {
      usageData.model = contentData["model"];
    }
    if (contentData["modelVersion"]) {
      usageData.model = contentData["modelVersion"];
    }
    if (contentData["message"] && contentData["message"]["model"]) {
      usageData.model = contentData["message"]["model"];
    }
    if (usageData.model && usageData.model.includes("/")) {
      var modelNamePieces = usageData.model.split("/");
      usageData.model = modelNamePieces[modelNamePieces.length - 1];
    }

    // requestTokenCount
    // openmodels / openai
    if (contentData["usage"] && contentData["usage"]["prompt_tokens"] !== undefined) {
      usageData.requestTokenCount = contentData["usage"]["prompt_tokens"];
    }
    // claude message.usage
    if (
      contentData["message"] &&
      contentData["message"]["usage"] &&
      contentData["message"]["usage"]["input_tokens"] !== undefined
    ) {
      usageData.requestTokenCount = contentData["message"]["usage"]["input_tokens"];
    }
    // claude top-level usage
    if (contentData["usage"] && contentData["usage"]["input_tokens"] !== undefined) {
      usageData.requestTokenCount = contentData["usage"]["input_tokens"];
    }
    // gemini API
    if (contentData["usageMetadata"] && contentData["usageMetadata"]["promptTokenCount"] !== undefined) {
      usageData.requestTokenCount = contentData["usageMetadata"]["promptTokenCount"];
    }

    // responseTokenCount
    // openmodels / openai
    if (contentData["usage"] && contentData["usage"]["completion_tokens"] !== undefined) {
      usageData.responseTokenCount = contentData["usage"]["completion_tokens"];
    }
    // claude message.usage
    if (
      contentData["message"] &&
      contentData["message"]["usage"] &&
      contentData["message"]["usage"]["output_tokens"] !== undefined
    ) {
      usageData.responseTokenCount = contentData["message"]["usage"]["output_tokens"];
    }
    // claude top-level usage
    if (contentData["usage"] && contentData["usage"]["output_tokens"] !== undefined) {
      usageData.responseTokenCount = contentData["usage"]["output_tokens"];
    }
    // gemini API
    if (contentData["usageMetadata"] && contentData["usageMetadata"]["candidatesTokenCount"] !== undefined) {
      usageData.responseTokenCount = contentData["usageMetadata"]["candidatesTokenCount"];
    }

    if (usageData.requestTokenCount > 0 || usageData.responseTokenCount > 0) {
      usageData.usageFound = true;
    }
  } catch (e) {
    print("Exception in getUsageData: " + JSON.stringify(e));
  }

  return usageData;
}

function testAllowedModels(requestInfo) {
  var result = true;
  if (requestInfo.allowedModelPatterns && requestInfo.allowedModelPatterns != "ALL") {
    result = false;
    var patterns = requestInfo.allowedModelPatterns.split(";");
    for (var i = 0; i < patterns.length; i++) {
      var pattern = patterns[i];
      if (requestInfo.type == "googlecloud") {
        if (requestInfo.url.includes(pattern)) {
          result = true;
          break;
        }
      } else if (requestInfo.type == "oai" && requestInfo.requestContent["model"]) {
        if (requestInfo.requestContent["model"].includes(pattern)) {
          result = true;
          break;
        }
      }
    }
  }

  return result;
}

function testDeniedModels(requestInfo) {
  var result = true;
  if (requestInfo.deniedModelPatterns && requestInfo.deniedModelPatterns != "NONE") {
    var patterns = requestInfo.deniedModelPatterns.split(";");
    for (var i = 0; i < patterns.length; i++) {
      var pattern = patterns[i];
      if (requestInfo.type == "googlecloud") {
        if (requestInfo.url.includes(pattern)) {
          result = false;
          break;
        }
      } else if (requestInfo.type == "oai" && requestInfo.requestContent["model"]) {
        if (requestInfo.requestContent["model"].includes(pattern)) {
          result = false;
          break;
        }
      } else if (requestInfo.type == "oai") {
        result = false;
        break;
      }
    }
  }

  return result;
}

// Open AI to Gemini native format conversion
function convertOpenAiToGemini(openAiPayload) {
  if (!openAiPayload) return {};

  var geminiPayload = {
    contents: []
  };

  if (openAiPayload.messages && Array.isArray(openAiPayload.messages)) {
    var systemInstructionParts = [];

    for (var i = 0; i < openAiPayload.messages.length; i++) {
      var msg = openAiPayload.messages[i];
      var role = msg.role;
      var content = msg.content;

      if (role === "system") {
        if (typeof content === "string") {
          systemInstructionParts.push({ text: content });
        } else if (Array.isArray(content)) {
          for (var j = 0; j < content.length; j++) {
            if (content[j].type === "text" && content[j].text) {
              systemInstructionParts.push({ text: content[j].text });
            }
          }
        }
      } else {
        var geminiRole = (role === "assistant") ? "model" : "user";
        var parts = [];

        if (typeof content === "string") {
          parts.push({ text: content });
        } else if (Array.isArray(content)) {
          for (var k = 0; k < content.length; k++) {
            if (content[k].type === "text" && content[k].text) {
              parts.push({ text: content[k].text });
            }
          }
        }

        if (parts.length > 0) {
          geminiPayload.contents.push({
            role: geminiRole,
            parts: parts
          });
        }
      }
    }

    if (systemInstructionParts.length > 0) {
      geminiPayload.systemInstruction = {
        parts: systemInstructionParts
      };
    }
  }

  var generationConfig = {};
  if (openAiPayload.temperature !== undefined) generationConfig.temperature = openAiPayload.temperature;
  if (openAiPayload.top_p !== undefined) generationConfig.topP = openAiPayload.top_p;
  if (openAiPayload.max_tokens !== undefined) generationConfig.maxOutputTokens = openAiPayload.max_tokens;
  if (openAiPayload.stop !== undefined) {
    generationConfig.stopSequences = Array.isArray(openAiPayload.stop) ? openAiPayload.stop : [openAiPayload.stop];
  }

  if (Object.keys(generationConfig).length > 0) {
    geminiPayload.generationConfig = generationConfig;
  }

  return geminiPayload;
}

// OpenAI audio speech request to Gemini native audio format conversion
function convertOpenAiToGeminiAudio(openAiPayload) {
  if (!openAiPayload) return {};

  var inputText = "";
  if (typeof openAiPayload.input === "string") {
    inputText = openAiPayload.input;
  } else if (Array.isArray(openAiPayload.input)) {
    inputText = openAiPayload.input.join(" ");
  } else if (typeof openAiPayload.prompt === "string") {
    inputText = openAiPayload.prompt;
  }

  var voiceMap = {
    "alloy": "Puck",
    "echo": "Charon",
    "fable": "Kore",
    "onyx": "Fenrir",
    "nova": "Aoede",
    "shimmer": "Kore",
    "ash": "Puck",
    "coral": "Kore",
    "sage": "Charon",
    "verse": "Fenrir"
  };

  var rawVoice = openAiPayload.voice || "alloy";
  var voiceName = "Puck";
  if (voiceMap[rawVoice.toLowerCase()]) {
    voiceName = voiceMap[rawVoice.toLowerCase()];
  } else if (rawVoice) {
    voiceName = rawVoice;
  }

  return {
    contents: [
      {
        role: "user",
        parts: [
          { text: inputText }
        ]
      }
    ],
    generation_config: {
      response_modalities: ["AUDIO"],
      speech_config: {
        voice_config: {
          prebuilt_voice_config: {
            voice_name: voiceName
          }
        }
      }
    }
  };
}

function encodeBytesToBase64(data) {
  if (!data) return "";
  try {
    if (typeof java !== "undefined" && java.util && java.util.Base64) {
      if (typeof data === "string") {
        var bytes = data.split("").map(function(c) { return c.charCodeAt(0) & 0xFF; });
        return java.util.Base64.getEncoder().encodeToString(bytes);
      }
      return java.util.Base64.getEncoder().encodeToString(data);
    }
  } catch (e) {}
  try {
    if (typeof Buffer !== "undefined") {
      return Buffer.from(data).toString("base64");
    }
  } catch (e) {}
  return "";
}

function parseMultipartFormData(body, contentType) {
  var result = {
    model: "",
    prompt: "",
    language: "",
    fileMimeType: "audio/mp3",
    fileBase64: ""
  };

  if (!body) return result;

  var strBody = typeof body === "string" ? body : safeStringify(body);

  var boundary = "";
  if (contentType && contentType.includes("boundary=")) {
    var rawBoundary = contentType.split("boundary=")[1].split(";")[0].trim();
    if ((rawBoundary.startsWith('"') && rawBoundary.endsWith('"')) || (rawBoundary.startsWith("'") && rawBoundary.endsWith("'"))) {
      rawBoundary = rawBoundary.substring(1, rawBoundary.length - 1);
    }
    boundary = "--" + rawBoundary;
  } else if (typeof strBody === "string" && strBody.indexOf("--") === 0) {
    var firstLineEnd = strBody.indexOf("\r\n");
    if (firstLineEnd === -1) firstLineEnd = strBody.indexOf("\n");
    if (firstLineEnd !== -1) {
      boundary = strBody.substring(0, firstLineEnd).trim();
    }
  }

  if (!boundary) return result;

  var parts = strBody.split(boundary);
  for (var i = 0; i < parts.length; i++) {
    var part = parts[i];
    if (!part || part === "--" || part === "--\r\n" || part === "--\n") continue;

    var headerEndIndex = part.indexOf("\r\n\r\n");
    var delimiterLength = 4;
    if (headerEndIndex === -1) {
      headerEndIndex = part.indexOf("\n\n");
      delimiterLength = 2;
    }

    if (headerEndIndex === -1) continue;

    var headersText = part.substring(0, headerEndIndex);
    var bodyText = part.substring(headerEndIndex + delimiterLength);

    if (bodyText.endsWith("\r\n")) {
      bodyText = bodyText.substring(0, bodyText.length - 2);
    } else if (bodyText.endsWith("\n")) {
      bodyText = bodyText.substring(0, bodyText.length - 1);
    }

    var nameMatch = headersText.match(/name="([^"]+)"/i);
    var fieldName = nameMatch ? nameMatch[1] : "";

    if (fieldName === "model") {
      result.model = bodyText.trim();
    } else if (fieldName === "prompt") {
      result.prompt = bodyText.trim();
    } else if (fieldName === "language") {
      result.language = bodyText.trim();
    } else if (fieldName === "file") {
      var contentTypeMatch = headersText.match(/Content-Type:\s*([^\r\n;]+)/i);
      if (contentTypeMatch) {
        result.fileMimeType = contentTypeMatch[1].trim();
      }
      result.fileBase64 = encodeBytesToBase64(bodyText);
    }
  }

  return result;
}

function convertOpenAiMultipartToGemini(multipartData) {
  if (!multipartData) return {};

  var mimeType = multipartData.fileMimeType || "audio/mp3";
  var base64Data = multipartData.fileBase64 || "";
  var promptText = multipartData.prompt || "Transcribe this audio file accurately.";

  if (multipartData.language) {
    promptText += " The spoken language is " + multipartData.language + ".";
  }

  var parts = [];
  if (base64Data) {
    parts.push({
      inlineData: {
        mimeType: mimeType,
        data: base64Data
      }
    });
  }

  parts.push({
    text: promptText
  });

  return {
    contents: [
      {
        role: "user",
        parts: parts
      }
    ]
  };
}

function convertOpenAiToGeminiEmbeddings(openAiPayload) {
  if (!openAiPayload) return { content: { parts: [] } };

  var rawInput = openAiPayload.input || "";
  var textStr = "";

  if (Array.isArray(rawInput)) {
    textStr = rawInput.length > 0 ? rawInput[0] : "";
  } else if (typeof rawInput === "string") {
    textStr = rawInput;
  }

  return {
    content: {
      parts: [
        { text: textStr }
      ]
    }
  };
}

// Gemini embeddings response to OpenAI embeddings response conversion
function convertGeminiEmbeddingsToOpenAi(geminiResponse, modelName) {
  if (!geminiResponse) return { object: "list", data: [], model: modelName || "gemini-embedding" };

  var values = [];
  if (geminiResponse.embedding && geminiResponse.embedding.values) {
    values = geminiResponse.embedding.values;
  } else if (geminiResponse.predictions && Array.isArray(geminiResponse.predictions) && geminiResponse.predictions.length > 0) {
    var pred = geminiResponse.predictions[0];
    if (pred.embeddings && pred.embeddings.values) {
      values = pred.embeddings.values;
    } else if (pred.values) {
      values = pred.values;
    }
  }

  return {
    object: "list",
    data: [
      {
        object: "embedding",
        index: 0,
        embedding: values
      }
    ],
    model: modelName || "gemini-embedding",
    usage: {
      prompt_tokens: 0,
      total_tokens: 0
    }
  };
}

// Dispatcher for converting OpenAI payload to target provider & request type
function convertOpenAiPayload(openAiPayload, provider, requestType, routeInfo) {
  if (!openAiPayload) return {};

  var prov = (provider || "").toLowerCase();
  var type = (requestType || "text").toLowerCase();

  if (prov === "google") {
    if (type === "audio-text") {
      return convertOpenAiToGeminiAudio(openAiPayload);
    } else if (type === "audio-data") {
      return convertOpenAiMultipartToGemini(openAiPayload);
    } else if (type === "image-generation") {
      var modelStr = "";
      if (openAiPayload && openAiPayload.model) {
        modelStr = openAiPayload.model.toLowerCase();
      } else if (routeInfo && (routeInfo.cleanModelName || routeInfo.mappedModelName)) {
        modelStr = (routeInfo.mappedModelName || routeInfo.cleanModelName).toLowerCase();
      }
      if (modelStr.indexOf("imagen") !== -1) {
        return convertOpenAiToImagen(openAiPayload);
      } else {
        return convertOpenAiToGeminiImage(openAiPayload);
      }
    } else if (type === "embeddings") {
      return convertOpenAiToGeminiEmbeddings(openAiPayload);
    }
    return openAiPayload;
  } else if (prov === "anthropic") {
    return convertOpenAiToAnthropic(openAiPayload, routeInfo);
  }

  return openAiPayload;
}

// Extract raw base64 audio data and mimeType from Gemini TTS response
function convertGeminiAudioToOpenAi(geminiResponse) {
  var responseData = geminiResponse;
  if (typeof geminiResponse === "string") {
    try {
      responseData = JSON.parse(geminiResponse);
    } catch (e) {}
  }

  var base64Data = "";
  var mimeType = "audio/mpeg";

  if (responseData && responseData.candidates && Array.isArray(responseData.candidates) && responseData.candidates.length > 0) {
    var cand = responseData.candidates[0];
    if (cand && cand.content && cand.content.parts && Array.isArray(cand.content.parts) && cand.content.parts.length > 0) {
      for (var i = 0; i < cand.content.parts.length; i++) {
        var part = cand.content.parts[i];
        if (part) {
          var inline = part.inlineData || part.inline_data;
          if (inline && inline.data) {
            base64Data = inline.data;
            if (inline.mimeType) {
              mimeType = inline.mimeType;
            } else if (inline.mime_type) {
              mimeType = inline.mime_type;
            }
            break;
          }
        }
      }
    }
  }

  return {
    base64Data: base64Data,
    mimeType: mimeType
  };
}

// Helper to decode base64 string to native bytes (Java byte[] in Apigee, Buffer in Node)
function decodeBase64ToBytes(base64Str) {
  if (!base64Str) return "";
  try {
    if (typeof java !== "undefined" && java.util && java.util.Base64) {
      return java.util.Base64.getDecoder().decode(base64Str);
    }
  } catch (e) {}
  try {
    if (typeof Buffer !== "undefined") {
      return Buffer.from(base64Str, "base64");
    }
  } catch (e) {}
  return base64Str;
}

// Gemini native response to OpenAI format conversion
function convertGeminiToOpenAi(geminiResponse, modelName) {
  if (!geminiResponse) return {};

  var openAiResponse = {
    id: "chatcmpl-" + Math.random().toString(36).substring(2, 11),
    object: "chat.completion",
    created: Math.floor(Date.now() / 1000),
    model: modelName || "gemini",
    choices: [],
    usage: {
      prompt_tokens: 0,
      completion_tokens: 0,
      total_tokens: 0
    }
  };

  if (geminiResponse.candidates && Array.isArray(geminiResponse.candidates)) {
    for (var i = 0; i < geminiResponse.candidates.length; i++) {
      var candidate = geminiResponse.candidates[i];
      var text = "";

      if (candidate.content && candidate.content.parts && Array.isArray(candidate.content.parts)) {
        for (var p = 0; p < candidate.content.parts.length; p++) {
          if (candidate.content.parts[p].text) {
            text += candidate.content.parts[p].text;
          }
        }
      }

      var finishReason = "stop";
      if (candidate.finishReason) {
        if (candidate.finishReason === "MAX_TOKENS") finishReason = "length";
        else if (candidate.finishReason === "SAFETY") finishReason = "content_filter";
        else finishReason = candidate.finishReason.toLowerCase();
      }

      openAiResponse.choices.push({
        index: candidate.index || i,
        message: {
          role: "assistant",
          content: text
        },
        finish_reason: finishReason
      });
    }
  }

  if (geminiResponse.usageMetadata) {
    var promptTokens = geminiResponse.usageMetadata.promptTokenCount || 0;
    var completionTokens = geminiResponse.usageMetadata.candidatesTokenCount || 0;
    var totalTokens = geminiResponse.usageMetadata.totalTokenCount || (promptTokens + completionTokens);

    openAiResponse.usage = {
      prompt_tokens: promptTokens,
      completion_tokens: completionTokens,
      total_tokens: totalTokens
    };
  }

  return openAiResponse;
}

// OpenAI image generation request to Imagen native predict request conversion
function convertOpenAiToImagen(openAiPayload) {
  if (!openAiPayload) return { instances: [] };

  var promptText = openAiPayload.prompt || "";
  var sampleCount = openAiPayload.n || 1;

  var parameters = {};
  if (openAiPayload.response_format === "b64_json") {
    parameters.outputOptions = { mimeType: "image/jpeg" };
  }
  if (openAiPayload.aspect_ratio) {
    parameters.aspectRatio = openAiPayload.aspect_ratio;
  }
  if (sampleCount) {
    parameters.sampleCount = sampleCount;
  }

  return {
    instances: [{ prompt: promptText }],
    parameters: parameters
  };
}

// OpenAI image generation request to Gemini generateContent request conversion
function convertOpenAiToGeminiImage(openAiPayload) {
  if (!openAiPayload) return { contents: [] };

  var promptText = openAiPayload.prompt || "";
  var config = {
    responseModalities: ["IMAGE"]
  };

  if (openAiPayload.aspect_ratio) {
    config.aspectRatio = openAiPayload.aspect_ratio;
  }

  return {
    contents: [
      {
        role: "user",
        parts: [
          { text: promptText }
        ]
      }
    ],
    generationConfig: config
  };
}

// Imagen native predict response to OpenAI image generation response conversion
function convertImagenToOpenAi(imagenResponse, modelName) {
  if (!imagenResponse) return { created: Math.floor(Date.now() / 1000), data: [] };

  var openAiResponse = {
    created: Math.floor(Date.now() / 1000),
    data: []
  };

  if (imagenResponse.predictions && Array.isArray(imagenResponse.predictions)) {
    for (var i = 0; i < imagenResponse.predictions.length; i++) {
      var pred = imagenResponse.predictions[i];
      if (pred.bytesBase64Encoded) {
        openAiResponse.data.push({
          b64_json: pred.bytesBase64Encoded
        });
      } else if (pred.gcsUri) {
        openAiResponse.data.push({
          url: pred.gcsUri
        });
      }
    }
  } else if (imagenResponse.candidates && Array.isArray(imagenResponse.candidates)) {
    for (var c = 0; c < imagenResponse.candidates.length; c++) {
      var cand = imagenResponse.candidates[c];
      if (cand && cand.content && cand.content.parts && Array.isArray(cand.content.parts)) {
        for (var p = 0; p < cand.content.parts.length; p++) {
          var part = cand.content.parts[p];
          if (part) {
            var inline = part.inlineData || part.inline_data;
            if (inline && inline.data) {
              openAiResponse.data.push({
                b64_json: inline.data
              });
            }
          }
        }
      }
    }
  }

  return openAiResponse;
}

function getModelTokenLimit(modelName, quotaData) {
  var limit = -1;
  if (!modelName || !quotaData) {
    return limit;
  }

  var data = quotaData;
  if (typeof quotaData === "string") {
    try {
      data = JSON.parse(quotaData);
    } catch (e) {
      return limit;
    }
  } else if (quotaData && quotaData.asJSON) {
    data = quotaData.asJSON;
  }

  if (!data || !Array.isArray(data)) {
    return limit;
  }

  var cleanModel = modelName;
  if (modelName.indexOf("/") !== -1) {
    var parts = modelName.split("/");
    cleanModel = parts[parts.length - 1];
  }

  for (var i = 0; i < data.length; i++) {
    var entry = data[i];
    if (entry && entry.llmOperations && Array.isArray(entry.llmOperations)) {
      for (var j = 0; j < entry.llmOperations.length; j++) {
        var op = entry.llmOperations[j];
        if (op && op.model) {
          var opModel = op.model;
          var cleanOpModel = opModel;
          if (opModel.indexOf("/") !== -1) {
            var opParts = opModel.split("/");
            cleanOpModel = opParts[opParts.length - 1];
          }
          if (opModel === modelName || cleanOpModel === cleanModel) {
            if (
              entry.llmTokenQuota &&
              entry.llmTokenQuota.limit !== undefined &&
              entry.llmTokenQuota.limit !== null &&
              entry.llmTokenQuota.limit !== ""
            ) {
              return entry.llmTokenQuota.limit;
            }
          }
        }
      }
    }
  }

  return limit;
}

function getModelList(quotaData) {
  var result = {
    object: "list",
    data: []
  };

  if (!quotaData) {
    return result;
  }

  var data = quotaData;
  if (typeof quotaData === "string") {
    try {
      data = JSON.parse(quotaData);
    } catch (e) {
      return result;
    }
  } else if (quotaData && quotaData.asJSON) {
    data = quotaData.asJSON;
  }

  if (!data || !Array.isArray(data)) {
    return result;
  }

  var seenModels = {};
  var createdTimestamp = 1686935002;

  for (var i = 0; i < data.length; i++) {
    var entry = data[i];
    if (entry && entry.llmOperations && Array.isArray(entry.llmOperations)) {
      for (var j = 0; j < entry.llmOperations.length; j++) {
        var op = entry.llmOperations[j];
        if (op && op.model) {
          var modelId = op.model;
          if (!seenModels[modelId]) {
            seenModels[modelId] = true;
            result.data.push({
              id: modelId,
              object: "model",
              created: createdTimestamp,
              owned_by: "system"
            });
          }
        }
      }
    }
  }

  return result;
}

// OpenAI to Anthropic messages format conversion
function convertOpenAiToAnthropic(openAiPayload, routeInfo) {
  if (!openAiPayload) return {};

  var targetModel = openAiPayload.model || "";
  if (routeInfo) {
    if (typeof routeInfo === "string") {
      targetModel = routeInfo;
    } else if (typeof routeInfo === "object") {
      if (routeInfo.cleanModelName) {
        targetModel = routeInfo.cleanModelName;
      } else if (routeInfo.mappedModelName) {
        targetModel = routeInfo.mappedModelName;
      }
    }
  }

  if (targetModel && targetModel.indexOf("/") !== -1) {
    var parts = targetModel.split("/");
    targetModel = parts[parts.length - 1];
  }

  var anthropicPayload = {
    model: targetModel,
    messages: [],
    max_tokens: openAiPayload.max_tokens || openAiPayload.max_completion_tokens || 4096
  };

  var targetRoute = "";
  if (routeInfo) {
    if (typeof routeInfo === "string") {
      targetRoute = routeInfo;
    } else if (typeof routeInfo === "object" && routeInfo.targetRoute) {
      targetRoute = routeInfo.targetRoute;
    }
  }

  var lowerRoute = targetRoute.toLowerCase();
  if (!lowerRoute || lowerRoute.indexOf("google") !== -1) {
    anthropicPayload["anthropic_version"] = "vertex-2023-10-16";
    delete anthropicPayload.model;
  } else if (lowerRoute.indexOf("aws") !== -1 || lowerRoute.indexOf("bedrock") !== -1) {
    anthropicPayload["anthropic_version"] = "bedrock-2023-05-31";
    delete anthropicPayload.model;
  }

  var systemPrompts = [];

  if (openAiPayload.messages && Array.isArray(openAiPayload.messages)) {
    for (var i = 0; i < openAiPayload.messages.length; i++) {
      var msg = openAiPayload.messages[i];
      if (!msg) continue;
      var role = msg.role;
      var content = msg.content;

      if (role === "system" || role === "developer") {
        if (typeof content === "string") {
          systemPrompts.push(content);
        } else if (Array.isArray(content)) {
          for (var j = 0; j < content.length; j++) {
            if (content[j] && content[j].type === "text" && content[j].text) {
              systemPrompts.push(content[j].text);
            }
          }
        }
      } else {
        var anthropicRole = (role === "assistant") ? "assistant" : "user";
        var anthropicContent = content;

        if (Array.isArray(content)) {
          var formattedParts = [];
          for (var k = 0; k < content.length; k++) {
            var part = content[k];
            if (part) {
              if (part.type === "text") {
                formattedParts.push({ type: "text", text: part.text || "" });
              } else if (part.type === "image_url" && part.image_url) {
                var urlStr = typeof part.image_url === "string" ? part.image_url : part.image_url.url;
                if (urlStr && urlStr.startsWith("data:")) {
                  var matches = urlStr.match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
                  if (matches) {
                    formattedParts.push({
                      type: "image",
                      source: {
                        type: "base64",
                        media_type: matches[1],
                        data: matches[2]
                      }
                    });
                  }
                }
              }
            }
          }
          anthropicContent = formattedParts;
        }

        anthropicPayload.messages.push({
          role: anthropicRole,
          content: anthropicContent
        });
      }
    }
  }

  if (systemPrompts.length > 0) {
    anthropicPayload.system = systemPrompts.join("\n\n");
  }

  if (openAiPayload.temperature !== undefined) anthropicPayload.temperature = openAiPayload.temperature;
  if (openAiPayload.top_p !== undefined) anthropicPayload.top_p = openAiPayload.top_p;
  if (openAiPayload.stream !== undefined) anthropicPayload.stream = openAiPayload.stream;
  if (openAiPayload.stop !== undefined) {
    anthropicPayload.stop_sequences = Array.isArray(openAiPayload.stop) ? openAiPayload.stop : [openAiPayload.stop];
  }

  return anthropicPayload;
}

// Anthropic response to OpenAI format conversion (non-streaming)
function convertAnthropicToOpenAi(anthropicData, modelName) {
  var usageData = {
    model: modelName || "",
    requestTokenCount: 0,
    responseTokenCount: 0,
    totalTokenCount: 0,
    usageFound: false
  };

  if (!anthropicData) {
    return { contentString: "", usageData: usageData };
  }

  var data = anthropicData;
  if (typeof anthropicData === "string") {
    try {
      data = JSON.parse(anthropicData);
    } catch (e) {
      return { contentString: anthropicData, usageData: usageData };
    }
  }

  var text = "";
  if (data.content && Array.isArray(data.content)) {
    for (var i = 0; i < data.content.length; i++) {
      var item = data.content[i];
      if (item && item.type === "text" && item.text) {
        text += item.text;
      }
    }
  } else if (typeof data.content === "string") {
    text = data.content;
  }

  var finishReason = "stop";
  if (data.stop_reason) {
    if (data.stop_reason === "max_tokens") finishReason = "length";
    else if (data.stop_reason === "end_turn" || data.stop_reason === "stop_sequence") finishReason = "stop";
    else finishReason = data.stop_reason.toLowerCase();
  }

  var msgId = data.id ? ("chatcmpl-" + data.id.replace(/^msg_/, "")) : ("chatcmpl-" + Math.random().toString(36).substring(2, 11));

  var promptTokens = (data.usage && data.usage.input_tokens !== undefined) ? data.usage.input_tokens : 0;
  var completionTokens = (data.usage && data.usage.output_tokens !== undefined) ? data.usage.output_tokens : 0;

  var openAiResponse = {
    id: msgId,
    object: "chat.completion",
    created: Math.floor(Date.now() / 1000),
    model: modelName || data.model || "claude",
    choices: [
      {
        index: 0,
        message: {
          role: "assistant",
          content: text
        },
        finish_reason: finishReason
      }
    ],
    usage: {
      prompt_tokens: promptTokens,
      completion_tokens: completionTokens,
      total_tokens: promptTokens + completionTokens
    }
  };

  usageData.model = modelName || data.model || "claude";
  usageData.requestTokenCount = promptTokens;
  usageData.responseTokenCount = completionTokens;
  usageData.totalTokenCount = promptTokens + completionTokens;
  if (promptTokens > 0 || completionTokens > 0) {
    usageData.usageFound = true;
  }

  return {
    contentString: JSON.stringify(openAiResponse),
    usageData: usageData,
    openAiResponse: openAiResponse
  };
}

// Anthropic stream event chunk to OpenAI format conversion (streaming)
function convertAnthropicStreamToOpenAi(contentString, modelName, streamMessageId) {
  var usageData = {
    model: modelName || "",
    requestTokenCount: 0,
    responseTokenCount: 0,
    totalTokenCount: 0,
    usageFound: false
  };

  if (!contentString) {
    return { contentString: "", usageData: usageData, messageId: streamMessageId || "" };
  }

  var activeMsgId = streamMessageId || "";
  if (!activeMsgId && typeof context !== "undefined" && context && context.getVariable) {
    activeMsgId = context.getVariable("ai.streamMessageId") || "";
  }

  var rawBlocks = contentString.split(/\r?\n\r?\n/);
  var outputChunks = [];

  for (var b = 0; b < rawBlocks.length; b++) {
    var raw = rawBlocks[b].trim();
    if (!raw) continue;

    if (raw.indexOf("message_stop") !== -1 || raw.indexOf("[DONE]") !== -1) {
      outputChunks.push("data: [DONE]");
      continue;
    }

    var eventType = "";
    var dataLines = [];
    var lines = raw.split(/\r?\n/);

    for (var l = 0; l < lines.length; l++) {
      var line = lines[l].trim();
      if (line.indexOf("event:") === 0) {
        eventType = line.substring(6).trim();
      } else if (line.indexOf("data:") === 0) {
        dataLines.push(line.substring(5).trim());
      } else if (dataLines.length > 0 && line) {
        dataLines.push(line);
      }
    }

    var dataStr = dataLines.join("").trim();

    if (!dataStr && raw.indexOf("{") === 0) {
      dataStr = raw.trim();
    }

    var eventData = safeJsonParse(dataStr);
    if (!eventData) {
      continue;
    }

    try {
      var type = eventType || eventData.type || "";
      var created = Math.floor(Date.now() / 1000);
      var model = modelName || eventData.model || "claude";

      if (type === "message_start" && eventData.message) {
        if (eventData.message.id) {
          activeMsgId = "chatcmpl-" + eventData.message.id.replace(/^msg_/, "");
        } else if (!activeMsgId) {
          activeMsgId = "chatcmpl-" + Math.random().toString(36).substring(2, 11);
        }
        if (typeof context !== "undefined" && context && context.setVariable) {
          context.setVariable("ai.streamMessageId", activeMsgId);
        }

        var startChunk = {
          id: activeMsgId,
          object: "chat.completion.chunk",
          created: created,
          model: eventData.message.model || model,
          choices: [
            {
              index: 0,
              delta: { role: "assistant", content: "" },
              finish_reason: null
            }
          ]
        };

        if (eventData.message.usage) {
          var pTok = eventData.message.usage.input_tokens !== undefined ? eventData.message.usage.input_tokens : 0;
          var cTok = eventData.message.usage.output_tokens !== undefined ? eventData.message.usage.output_tokens : 0;
          startChunk.usage = {
            prompt_tokens: pTok,
            completion_tokens: cTok,
            total_tokens: pTok + cTok
          };
          usageData.requestTokenCount = pTok;
          usageData.responseTokenCount = cTok;
          usageData.totalTokenCount = pTok + cTok;
          if (pTok > 0 || cTok > 0) {
            usageData.usageFound = true;
          }
        }

        outputChunks.push("data: " + JSON.stringify(startChunk));
        continue;
      }

      if (!activeMsgId) {
        activeMsgId = "chatcmpl-" + Math.random().toString(36).substring(2, 11);
      }

      if (type === "content_block_start" && eventData.content_block) {
        var cb = eventData.content_block;
        var blockIndex = eventData.index || 0;

        if (cb.type === "tool_use") {
          var toolStartChunk = {
            id: activeMsgId,
            object: "chat.completion.chunk",
            created: created,
            model: model,
            choices: [
              {
                index: 0,
                delta: {
                  tool_calls: [
                    {
                      index: blockIndex,
                      id: cb.id || "",
                      type: "function",
                      function: {
                        name: cb.name || "",
                        arguments: ""
                      }
                    }
                  ]
                },
                finish_reason: null
              }
            ]
          };
          outputChunks.push("data: " + JSON.stringify(toolStartChunk));
        } else if (cb.type === "text" && cb.text) {
          var textStartChunk = {
            id: activeMsgId,
            object: "chat.completion.chunk",
            created: created,
            model: model,
            choices: [
              {
                index: 0,
                delta: { content: cb.text },
                finish_reason: null
              }
            ]
          };
          outputChunks.push("data: " + JSON.stringify(textStartChunk));
        }
        continue;
      }

      if (type === "content_block_delta" && eventData.delta) {
        var deltaObj = eventData.delta;
        var blockIdx = eventData.index || 0;

        if (deltaObj.type === "text_delta" && deltaObj.text !== undefined) {
          var deltaChunk = {
            id: activeMsgId,
            object: "chat.completion.chunk",
            created: created,
            model: model,
            choices: [
              {
                index: 0,
                delta: { content: deltaObj.text },
                finish_reason: null
              }
            ]
          };
          outputChunks.push("data: " + JSON.stringify(deltaChunk));
        } else if (deltaObj.type === "thinking_delta" && deltaObj.thinking !== undefined) {
          var thinkingChunk = {
            id: activeMsgId,
            object: "chat.completion.chunk",
            created: created,
            model: model,
            choices: [
              {
                index: 0,
                delta: { reasoning_content: deltaObj.thinking },
                finish_reason: null
              }
            ]
          };
          outputChunks.push("data: " + JSON.stringify(thinkingChunk));
        } else if (deltaObj.type === "input_json_delta" && deltaObj.partial_json !== undefined) {
          var toolDeltaChunk = {
            id: activeMsgId,
            object: "chat.completion.chunk",
            created: created,
            model: model,
            choices: [
              {
                index: 0,
                delta: {
                  tool_calls: [
                    {
                      index: blockIdx,
                      function: { arguments: deltaObj.partial_json }
                    }
                  ]
                },
                finish_reason: null
              }
            ]
          };
          outputChunks.push("data: " + JSON.stringify(toolDeltaChunk));
        }
        continue;
      }

      if (type === "content_block_stop") {
        continue;
      }

      if (type === "message_delta" && eventData.delta) {
        var stopReason = eventData.delta.stop_reason;
        var finishReason = "stop";
        if (stopReason === "max_tokens") finishReason = "length";
        else if (stopReason === "end_turn" || stopReason === "stop_sequence") finishReason = "stop";
        else if (stopReason === "tool_use") finishReason = "tool_calls";
        else if (stopReason) finishReason = stopReason.toLowerCase();

        var stopChunk = {
          id: activeMsgId,
          object: "chat.completion.chunk",
          created: created,
          model: model,
          choices: [
            {
              index: 0,
              delta: {},
              finish_reason: finishReason
            }
          ]
        };

        if (eventData.usage) {
          var promptTok = eventData.usage.input_tokens !== undefined ? eventData.usage.input_tokens : 0;
          var compTok = eventData.usage.output_tokens !== undefined ? eventData.usage.output_tokens : 0;
          stopChunk.usage = {
            prompt_tokens: promptTok,
            completion_tokens: compTok,
            total_tokens: promptTok + compTok
          };
          usageData.requestTokenCount = promptTok;
          usageData.responseTokenCount = compTok;
          usageData.totalTokenCount = promptTok + compTok;
          if (promptTok > 0 || compTok > 0) {
            usageData.usageFound = true;
          }
        }

        outputChunks.push("data: " + JSON.stringify(stopChunk));
        continue;
      }

      if (type === "ping") {
        continue;
      }

    } catch (e) {
    }
  }

  return {
    contentString: outputChunks.join("\n\n"),
    usageData: usageData,
    messageId: activeMsgId
  };
}

if (typeof exports !== "undefined") {
  exports.safeStringify = safeStringify;
  exports.getRequestInfo = getRequestInfo;
  exports.getModelName = getModelName;
  exports.getTargetRoute = getTargetRoute;
  exports.getPrompts = getPrompts;
  exports.setPrompt = setPrompt;
  exports.getResponse = getResponse;
  exports.setResponse = setResponse;
  exports.getUsageData = getUsageData;
  exports.testAllowedModels = testAllowedModels;
  exports.testDeniedModels = testDeniedModels;
  exports.encodeBytesToBase64 = encodeBytesToBase64;
  exports.parseMultipartFormData = parseMultipartFormData;
  exports.convertOpenAiMultipartToGemini = convertOpenAiMultipartToGemini;
  exports.convertOpenAiToGeminiEmbeddings = convertOpenAiToGeminiEmbeddings;
  exports.convertGeminiEmbeddingsToOpenAi = convertGeminiEmbeddingsToOpenAi;
  exports.convertOpenAiToGemini = convertOpenAiToGemini;
  exports.convertOpenAiToGeminiAudio = convertOpenAiToGeminiAudio;
  exports.convertGeminiAudioToOpenAi = convertGeminiAudioToOpenAi;
  exports.decodeBase64ToBytes = decodeBase64ToBytes;
  exports.convertOpenAiPayload = convertOpenAiPayload;
  exports.convertGeminiToOpenAi = convertGeminiToOpenAi;
  exports.convertOpenAiToImagen = convertOpenAiToImagen;
  exports.convertOpenAiToGeminiImage = convertOpenAiToGeminiImage;
  exports.convertImagenToOpenAi = convertImagenToOpenAi;
  exports.convertOpenAiToAnthropic = convertOpenAiToAnthropic;
  exports.convertAnthropicToOpenAi = convertAnthropicToOpenAi;
  exports.convertAnthropicStreamToOpenAi = convertAnthropicStreamToOpenAi;
  exports.getModelTokenLimit = getModelTokenLimit;
  exports.getModelList = getModelList;
}
